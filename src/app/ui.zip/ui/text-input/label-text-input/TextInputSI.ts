export interface  TextInputSI {
  error: string;
  success: string;
  empty: string;
}
