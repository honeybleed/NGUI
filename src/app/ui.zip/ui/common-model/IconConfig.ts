export class IconConfig {
  fontFamily: string;
  iconMap: object;
  hello: string;
}
